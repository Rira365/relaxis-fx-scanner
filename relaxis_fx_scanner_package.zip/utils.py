# Utility functions

def get_prediction():
    return '↑', 85.6