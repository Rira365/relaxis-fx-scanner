# Main Streamlit App
import streamlit as st
st.title('Relaxis FX Scanner')